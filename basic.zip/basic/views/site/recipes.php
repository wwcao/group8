<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Use these links to find delicious recipes!';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-recipes">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <a href="http://allrecipes.com">Allrecipes</a>


    </p>
    <p>
    	<a href="http://www.epicurious.com">Epicurious</a>

     </p>
     <p>
     	 <a href="http://www.food.com">Food</a>

      </p>
      <p>
      <a href="http://www.simplyrecipes.com">Simply Recipes</a>
      </p>

    
</div>
